# ===========================================================================
# Copyright (C) 2021 Infineon Technologies AG
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from ltr11 import *
import numpy as np


def config2string(ltr11, config):
    device_info = ltr11.get_device_info()
    min_rf_frequency = device_info["min_rf_frequency_kHz"]
    chip_version = device_info["major_version_hw"]
    # the lookup dictionaries must agree with the values
    # in EndpointRadarBGT60LTR11.h in the directory sdk/c/radar_comm
    mode = {0: "continuous wave", 1: "pulse mode"}
    adc = {0: "using LTR11 ADCs", 1: "using RadarBaseboardMCU7 ADCs"}
    prt = {0: "250µs", 1: "500µs", 2: "1000µs", 3: "2000µs"}

    if (chip_version < 3):
        pw = {0: "5µs", 1: "10µs", 2: "20µs", 3: "40µs"}
        hold_time = {
            0: "10ms",
            1: "20ms",
            2: "40ms",
            3: "80ms",
            4: "1s",
            5: "2s",
            6: "4s",
            7: "8s",
            8: "10s",
            9: "20s",
            10: "40s",
            12: "60s",
            11: "80s",
            13: "2min",
            14: "4min",
            15: "8min"
        }
    else:
        pw = {0: "5µs", 1: "10µs", 2: "3µs", 3: "4µs"}
        hold_time = {
            0: "minimum",
            1: "500ms",
            2: "1s",
            3: "2s",
            4: "3s",
            5: "5s",
            6: "10s",
            7: "30s",
            8: "45s",
            9: "60s",
            10: "90s",
            11: "2min",
            12: "5min",
            13: "10min",
            14: "15min",
            15: "30min",
        }

    def rx_if_gain(gain): return str(10+5*gain)
    '''
    The list of RF frequencies can be found either in the documentation or in the ltr11.py script.
    There is a difference of 25MHz between the RF frequencies. 
    Hence, the rf_frequency can be computed from the sum of the minimum RF frequency
    (depends on pll_japan_mode) and the index of the frequency in the list multiplied by 25MHz.
    '''
    rf_frequency = int(min_rf_frequency/1000) + config["rf_center_freq"] * 25

    s = "operation mode:           " + mode[config["mode"]] + "\n"
    s += "pulse width:              " + pw[config["pulse_width"]] + "\n"
    s += "pulse repetition time:    " + prt[config["pulse_repetition"]] + "\n"
    s += "hold time:                " + hold_time[config["hold_time"]] + "\n"
    s += "adc:                      " + adc[config["adc"]] + "\n"
    s += "tx power:                 " + str(config["tx_power_level"]) + "\n"
    s += "rx if gain:               " + rx_if_gain(config["rx_if_gain"]) + "dB\n"
    s += "sensitivity:              " + str(14 - config["detection_threshold"]) + "\n"
    s += "sampling frequency:       " + str(config["sampling_frequency"]) + "Hz" + "\n"
    s += "center rf frequency:      " + str(rf_frequency) + "MHz"
    return s


if __name__ == "__main__":
    ltr11 = BGT60LTR11()
    config = ltr11.get_configuration()
    print(config2string(ltr11, config))
